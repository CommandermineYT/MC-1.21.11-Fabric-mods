package com.totalecollapse;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.brigadier.Command;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1540;
import net.minecraft.class_2170;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class TotaleCollapse implements ModInitializer {
    public static final String MOD_ID = "totale-collapse";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static final List<class_1540> ACTIVE_METEORS = new ArrayList<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                class_2170.method_9247("collapse")
                    .then(class_2170.method_9247("meteor")
                        .executes(context -> {
                            class_3218 level = context.getSource().method_9225();
                            class_243 origin = context.getSource().method_9222();

                            class_2338 spawnPos = class_2338.method_49637(
                                origin.field_1352,
                                origin.field_1351 + 30.0,
                                origin.field_1350
                            );

                            class_1540 meteor = class_1540.method_40005(
                                level,
                                spawnPos,
                                class_2246.field_10092.method_9564()
                            );

                            meteor.method_18800(0.35, -0.80, 0.35);
                            meteor.field_7193 = false;

                            ACTIVE_METEORS.add(meteor);

                            context.getSource().method_9226(
                                () -> class_2561.method_43470("Total collapse initiated"),
                                true
                            );

                            return Command.SINGLE_SUCCESS;
                        })
                    )
            );
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> tickMeteors());
    }

    private static void tickMeteors() {
        Iterator<class_1540> iterator = ACTIVE_METEORS.iterator();

        while (iterator.hasNext()) {
            class_1540 meteor = iterator.next();

            if (!meteor.method_5805()) {
                spawnImpactBurst((class_3218) meteor.method_73183(), meteor.method_73189());
                iterator.remove();
                continue;
            }

            class_3218 level = (class_3218) meteor.method_73183();
            class_243 position = meteor.method_73189();

            level.method_65096(
                class_2398.field_11240,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                6,
                0.25,
                0.25,
                0.25,
                0.02
            );

            level.method_65096(
                class_2398.field_11237,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                4,
                0.3,
                0.3,
                0.3,
                0.01
            );
        }
    }

    private static void spawnImpactBurst(class_3218 level, class_243 position) {
        level.method_65096(
            class_2398.field_11221,
            position.field_1352,
            position.field_1351,
            position.field_1350,
            1,
            0.0,
            0.0,
            0.0,
            0.0
        );

        level.method_65096(
            class_2398.field_11240,
            position.field_1352,
            position.field_1351,
            position.field_1350,
            30,
            1.2,
            0.4,
            1.2,
            0.12
        );

        level.method_65096(
            class_2398.field_11237,
            position.field_1352,
            position.field_1351,
            position.field_1350,
            20,
            1.0,
            0.5,
            1.0,
            0.08
        );
    }
}