package com.totalecollapse.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;

public class TotaleCollapseClient implements ClientModInitializer {
    private static final int METEOR_COUNT = 35;
    private static final double MIN_RADIUS = 4.0;
    private static final double MAX_RADIUS = 50.0;
    private static final double START_HEIGHT = 30.0;
    private static final double MIN_ANGLE = 40.0;
    private static final double MAX_ANGLE = 50.0;
    private static final double SPEED = 0.75;

    private static final Random RANDOM = new Random();
    private static final List<Meteor> METEORS = new ArrayList<>();

    @Override
    public void onInitializeClient() {
       

        ClientTickEvents.END_CLIENT_TICK.register(TotaleCollapseClient::tickMeteors);
    }

    private static void createMeteorShower() {
        class_310 minecraft = class_310.method_1551();

        if (minecraft.field_1724 == null) {
            return;
        }

        class_243 playerPosition = minecraft.field_1724.method_73189();

        for (int i = 0; i < METEOR_COUNT; i++) {
            double direction = RANDOM.nextDouble() * Math.PI * 2.0;
            double distance = MIN_RADIUS + RANDOM.nextDouble() * (MAX_RADIUS - MIN_RADIUS);

            double targetX = playerPosition.field_1352 + Math.cos(direction) * distance;
            double targetZ = playerPosition.field_1350 + Math.sin(direction) * distance;

            class_243 start = new class_243(
                playerPosition.field_1352,
                playerPosition.field_1351 + START_HEIGHT,
                playerPosition.field_1350
            );

            class_243 target = new class_243(targetX, playerPosition.field_1351, targetZ);

            class_243 horizontalDirection = new class_243(
                target.field_1352 - start.field_1352,
                0.0,
                target.field_1350 - start.field_1350
            ).method_1029();

            double angle = Math.toRadians(
                MIN_ANGLE + RANDOM.nextDouble() * (MAX_ANGLE - MIN_ANGLE)
            );

            double horizontalSpeed = SPEED * Math.cos(angle);
            double downwardSpeed = SPEED * Math.sin(angle);

            class_243 velocity = new class_243(
                horizontalDirection.field_1352 * horizontalSpeed,
                -downwardSpeed,
                horizontalDirection.field_1350 * horizontalSpeed
            );

            METEORS.add(new Meteor(start, velocity, target));
        }
    }

    private static void tickMeteors(class_310 minecraft) {
        class_638 level = minecraft.field_1687;

        if (level == null) {
            METEORS.clear();
            return;
        }

        Iterator<Meteor> iterator = METEORS.iterator();

        while (iterator.hasNext()) {
            Meteor meteor = iterator.next();

            meteor.position = meteor.position.method_1019(meteor.velocity);

            level.method_8406(
                class_2398.field_11240,
                meteor.position.field_1352,
                meteor.position.field_1351,
                meteor.position.field_1350,
                0.0,
                0.0,
                0.0
            );

            level.method_8406(
                class_2398.field_11251,
                meteor.position.field_1352,
                meteor.position.field_1351,
                meteor.position.field_1350,
                0.0,
                0.02,
                0.0
            );

            if (meteor.position.field_1351 <= meteor.target.field_1351) {
                createImpact(level, meteor.target);
                iterator.remove();
            }
        }
    }

    private static void createImpact(class_638 level, class_243 position) {
        level.method_8406(
            class_2398.field_11221,
            position.field_1352,
            position.field_1351,
            position.field_1350,
            0.0,
            0.0,
            0.0
        );

        for (int i = 0; i < 12; i++) {
            double velocityX = (RANDOM.nextDouble() - 0.5) * 0.35;
            double velocityY = RANDOM.nextDouble() * 0.25;
            double velocityZ = (RANDOM.nextDouble() - 0.5) * 0.35;

            level.method_8406(
                class_2398.field_11240,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                velocityX,
                velocityY,
                velocityZ
            );

            level.method_8406(
                class_2398.field_11251,
                position.field_1352,
                position.field_1351,
                position.field_1350,
                velocityX,
                velocityY,
                velocityZ
            );
        }
    }

    private static class Meteor {
        private class_243 position;
        private final class_243 velocity;
        private final class_243 target;

        private Meteor(class_243 position, class_243 velocity, class_243 target) {
            this.position = position;
            this.velocity = velocity;
            this.target = target;
        }
    }
}